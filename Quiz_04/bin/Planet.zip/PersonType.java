
public enum PersonType {
AWESOME,
VERY_GOOD,
GOOD,
OKAY,
BAD,
VERY_BAD,
EVAL;
}
