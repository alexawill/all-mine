
public enum ShipType {
CARGO,
PASSENGER,
FIGHTER
}
