
public interface IHostPeople {
public void addPerson(Person p);	

public void removePerson(Person p);

public void removePerson(int a);
}
