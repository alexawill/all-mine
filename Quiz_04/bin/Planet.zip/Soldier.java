
public class Soldier extends Person {

	public Soldier(String name, PersonType personType) {
		super(name, personType);
	}

}
