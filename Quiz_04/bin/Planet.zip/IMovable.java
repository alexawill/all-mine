
public interface IMovable {
	
	public void move();
}
