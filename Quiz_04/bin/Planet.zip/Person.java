
public class Person {
	//Properties
	String name;
	PersonType personType;

	//Constructors
	public Person(String name, PersonType personType){
		this.name = name;
		this.personType = personType;
	}
	
	//Methods
	public void move(){
	}
}
