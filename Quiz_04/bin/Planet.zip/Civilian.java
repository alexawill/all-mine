
public class Civilian extends Person {

	public Civilian(String name, PersonType personType) {
		super(name, personType);
	}

}
